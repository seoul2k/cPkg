# cPkg

## This is a package that generates packages

>## install
>>```shell
>>pip install cpkg
>>```
>## use
>>```python
>>import cpkg
>>cpkg.create(
>>    path='',
>>    dirName='',
>>    pkgName='',
>>    author='',
>>    author_email='',
>>    description='',
>>    url='',
>>    project_urls={},
>>    classifiers=[],
>>    python_requires=3.6,
>>    install_requires=[]
>>)
>>```
### or
```shell
createpkg optional
```
For more information, see
```shell
createpkg -h
```
## updata
>### 0.0.6 2021 1 19
>>1. Update command:
>>>See details:
>>>```shell
>>>python3 -m cpkg -h
>>>```
>>
>### 0.0.7 2021 1 19
>>Update Info
>### 0.0.8 2021 1 19
>>Repair Bug
>### 0.0.9 2021 1 19
>>Repair Bug
>### 0.0.13 2021 1 24
>>Repair Bug
>### 0.0.18 2022 3 27
>>Convert module to command line tool
>### 0.1.9 2022 3 27
>>Updata README.md
>### 0.1.10 2021 1 19
>>Repair Bug
>### 0.1.11 2021 1 19
>>Add new elements from setup.py